/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan_gui;

import java.io.File;
public class DemoGantiNamaFile {
    public static void main(String[] args){
        File f = new File("E:/Latiha_GUI/contoh.txt");
        if(f.exists()){
            f.renameTo(new File("E:/Latihan_GUI/sample.txt"));
            System.out.println("Sukses mengganti nama file");
        }else{
            System.out.println("File yang dimaksud tidak ada!");
        }
        
    }
            
            
    
}
