/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan_gui;

import java.io.File;
import java.io.IOException;
public class DemoHapusFile {
    public static void main(String[] args)throws Exception{
        File f = new File("E./Latihan_GUI/latihan.txt");
        f.delete();
        System.out.println("sukses menghapus file latihan.txt");
    }
    
}
