/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan_gui;

import java.io.FileWriter;
import java.io.IOException;
public class DemoTulisFile {
    public static void main(String args[])throws IOException{
        FileWriter fw = new FileWriter("E:/Latihan_GUI/contoh.txt");
        fw.write("Selamat Datang!");
        fw.close();
        System.out.println("Berhasil...");
        
    }
    
}
